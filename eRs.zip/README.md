# eRs
e₹
